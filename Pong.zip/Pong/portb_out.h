/*
 * File:   portb_out.h

 */

#ifndef PORTB_OUT_H
#define	PORTB_OUT_H
#include <inttypes.h>

extern void portb_out_init();

extern void portb_out_write(uint16_t v);

#endif	/* PORTB_OUT_H */
