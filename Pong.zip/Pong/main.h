/*
 * File:   main.h
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <xc.h>
#include <inttypes.h>



#ifdef	__cplusplus
}
#endif
