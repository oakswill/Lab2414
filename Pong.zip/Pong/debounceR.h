/*
 * File:   debounceR.h
 * Author: phelana
 *
 * Created on September 21, 2021, 2:41 PM
 */

#ifndef DEBOUNCER_H
#define	DEBOUNCER_H

#ifdef	__cplusplus
extern "C" {
#endif

extern void buttondebounceR(uint8_t press);


#ifdef	__cplusplus
}
#endif

#endif	/* DEBOUNCER_H */
