/*
 * File:   debounceL.h
 */

#ifndef DEBOUNCEL_H
#define	DEBOUNCEL_H

#ifdef	__cplusplus
extern "C" {
#endif

extern void buttondebounceL(uint8_t press);


#ifdef	__cplusplus
}
#endif

#endif	/* DEBOUNCEL_H */
