/*
 * File:   porta_in.h

 */

#ifndef PORTA_IN_H
#define	PORTA_IN_H
#include <inttypes.h>

extern void porta_in_init();

extern uint8_t porta_in_read();

#endif	/* PORTA_IN_H */
